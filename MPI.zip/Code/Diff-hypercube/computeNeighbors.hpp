#include <iostream>
#include <vector>

int computePredecessor(int node);

std::vector<int> computeOutNeighbors(int node, int numberNodes);

void printNeighbors(std::vector<int> neighbors);
